import styles from "./Testimonials.module.css";
export default function Testimonials() {
  return <div>Testimonials</div>;
}
