import styles from "./RecipePagination.module.css";
export default function RecipePagination() {
  return <div>RecipePagination</div>;
}
