import styles from "./RecipeList.module.css";
export default function RecipeList() {
  return <div>RecipeList</div>;
}
