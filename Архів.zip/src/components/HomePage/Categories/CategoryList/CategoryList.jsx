import styles from "./CategoryList.module.css";
export default function CategoryList() {
  return <div>CategoryList</div>;
}
