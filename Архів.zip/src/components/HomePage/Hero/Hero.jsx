import styles from "./Hero.module.css";
export default function Hero() {
  return <div>Hero</div>;
}
