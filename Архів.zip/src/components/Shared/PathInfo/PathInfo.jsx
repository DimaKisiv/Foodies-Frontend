import styles from "./PathInfo.module.css";
export default function PathInfo() {
  return <div>PathInfo</div>;
}
