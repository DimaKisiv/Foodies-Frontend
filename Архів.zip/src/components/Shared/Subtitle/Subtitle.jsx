import styles from "./Subtitle.module.css";
export default function Subtitle() {
  return <div>Subtitle</div>;
}
