import styles from "./MainTitle.module.css";
export default function MainTitle() {
  return <div>MainTitle</div>;
}
