import styles from "./RecipeCard.module.css";
export default function RecipeCard() {
  return <div>RecipeCard</div>;
}
