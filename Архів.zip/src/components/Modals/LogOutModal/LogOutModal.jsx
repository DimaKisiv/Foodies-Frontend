import styles from "./LogOutModal.module.css";
export default function LogOutModal() {
  return <div>LogOutModal</div>;
}
