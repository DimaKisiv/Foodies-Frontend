import styles from "./SignUpForm.module.css";
export default function SignUpForm() {
  return <div>SignUpForm</div>;
}
