import styles from "./SignUpModal.module.css";
export default function SignUpModal() {
  return <div>SignUpModal</div>;
}
