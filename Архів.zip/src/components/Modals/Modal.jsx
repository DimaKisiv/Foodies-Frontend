import styles from "./Modal.module.css";
