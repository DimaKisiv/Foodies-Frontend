import styles from "./ListPagination.module.css";
export default function ListPagination() {
  return <div>ListPagination</div>;
}
