import styles from "./RecipePreview.module.css";
export default function RecipePreview() {
  return <div>RecipePreview</div>;
}
