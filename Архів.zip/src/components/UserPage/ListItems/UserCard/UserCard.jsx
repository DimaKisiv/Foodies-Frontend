import styles from "./UserCard.module.css";
export default function UserCard() {
  return <div>UserCard</div>;
}
