import styles from "./TabsList.module.css";
export default function TabsList() {
  return <div>TabsList</div>;
}
