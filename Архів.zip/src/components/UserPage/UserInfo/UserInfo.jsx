import styles from "./UserInfo.module.css";
export default function UserInfo() {
  return <div>UserInfo</div>;
}
