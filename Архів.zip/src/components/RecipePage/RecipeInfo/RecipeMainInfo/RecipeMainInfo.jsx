import styles from "./RecipeMainInfo.module.css";
export default function RecipeMainInfo() {
  return <div>RecipeMainInfo</div>;
}
