import styles from "./RecipePreparation.module.css";
export default function RecipePreparation() {
  return <div>RecipePreparation</div>;
}
