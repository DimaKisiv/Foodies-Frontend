import styles from "./RecipeIngredients.module.css";
export default function RecipeIngredients() {
  return <div>RecipeIngredients</div>;
}
