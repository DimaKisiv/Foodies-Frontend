const FollowingPage = () => {
  return (
    <section>
      <h2>Following</h2>
    </section>
  );
};

export default FollowingPage;
