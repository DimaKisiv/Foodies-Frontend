const FollowersPage = () => {
  return (
    <section>
      <h2>Followers</h2>
    </section>
  );
};

export default FollowersPage;
