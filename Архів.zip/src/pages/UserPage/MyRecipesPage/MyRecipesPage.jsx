const MyRecipesPage = () => {
  return (
    <section>
      <h2>My Recipes</h2>
    </section>
  );
};

export default MyRecipesPage;
