const AddRecipePage = () => {
  return <section>Add Recipe Page</section>;
};

export default AddRecipePage;
